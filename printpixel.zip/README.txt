Please refer to the "docs/" folder for documentation
