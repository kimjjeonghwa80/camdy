<script type='text/javascript'>
window.onload = function() {
    if (window.opener) {
        window.close();
    }
};
</script>